# UVA 10080 — Gopher II
### Grupo F · Resolução de Problemas com Grafos

Emparelhamento bipartido como fluxo máximo com capacidades unitárias.

---

## 1. Contexto e objetivo  ·  ~1 min

- `n` toupeiras, `m` buracos, no plano.
- O falcão chega: toupeira que não alcança um buraco em `s` segundos vira presa.
- Cada buraco abriga **1** toupeira; todas correm à velocidade `v`.
- **Objetivo: minimizar o número de toupeiras vulneráveis.**

Como cada toupeira anda no máximo `s · v` metros, ela só usa buracos a
distância `≤ s · v`. Maximizar toupeiras salvas = **emparelhamento máximo**.

---

## 2. Modelagem da rede  ·  ~1 min

```
            cap 1                 cap 1                cap 1
 source ───────────▶ TOUPEIRAS ─────────────▶ BURACOS ──────────▶ sink
                       (n)      (se alcança)     (m)
```

- **Origem → toupeira:** cap `1` → cada toupeira salva no máximo 1 vez.
- **Toupeira → buraco:** cap `1`, só se `dist² ≤ (s·v)²` → compatibilidade.
- **Buraco → sorvedouro:** cap `1` → cada buraco salva no máximo 1 toupeira.

Uma unidade de fluxo = **uma toupeira salva em um buraco alcançável**.
Capacidades unitárias porque toupeira e buraco são indivisíveis.

> Truque: comparar **distâncias ao quadrado** evita `sqrt` e erros de ponto
> flutuante. `≤` garante que a borda exata conta como alcançável.

---

## 3. Algoritmo e grafo residual  ·  ~1 min

- **Edmonds-Karp** = Ford-Fulkerson com **BFS** para o caminho aumentante.
- Cada aresta tem uma **reversa** (cap inicial `0`) → grafo residual.
- A cada caminho: gargalo = `1` → subtrai na direta, soma na reversa.
- A reversa permite **desfazer** uma escolha e redistribuir o fluxo.
- **Parada:** não há mais caminho de `source` a `sink` no residual.

Escolha previsível e mais que suficiente: grafo pequeno (`n, m < 100`),
capacidades unitárias.

---

## 4. Do fluxo para a resposta  ·  ~1 min

- **Fluxo máximo** = nº máximo de toupeiras em buracos distintos
  = emparelhamento bipartido máximo.
- As que sobram não têm buraco:

```
vulneráveis = n − fluxo_máximo
```

**Exemplo oficial:** 2 toupeiras só alcançam o mesmo buraco → fluxo = 1 →
`2 − 1 = 1` vulnerável. ✔

---

## 5. Complexidade e casos especiais  ·  ~1 min

- Construção da rede: `O(n · m)`.
- Edmonds-Karp: `O(V · E²)` no pior caso; aqui, instantâneo.
- Memória: lista de arestas residuais, `O(n · m)`.

**Casos especiais:**

- vários casos de teste por entrada (lê até `EOF`);
- nenhum buraco alcançável → `vulneráveis = n`;
- borda exata (`dist == s·v`) conta como alcançável;
- mais toupeiras que buracos (ou o contrário) → capacidade unitária limita a
  `min(n, m)`.

---

## Conclusão

Modelando alcance como compatibilidade bipartida e capacidades unitárias nas
duas pontas, o **fluxo máximo** resolve diretamente o **emparelhamento máximo**,
e a resposta é simplesmente `n − fluxo`. Submissão **Accepted** na UVA.
