# Ficha de Acompanhamento — UVA 10080: Gopher II

Grupo F — Resolução de Problemas com Grafos

## 1. Resumo do problema (em linguagem própria)

Existem `n` toupeiras e `m` buracos no plano. Um falcão aparece e qualquer
toupeira que não chegar a um buraco dentro de `s` segundos é comida. Cada buraco
só abriga uma toupeira, e todas correm à mesma velocidade `v`. Queremos descobrir
**quantas toupeiras, no mínimo, ficam sem buraco** (vulneráveis).

Como toda toupeira percorre no máximo `s · v` metros, ela só consegue usar um
buraco que esteja a uma distância `≤ s · v`. O problema vira: dado quem alcança o
quê, **emparelhar o maior número possível de toupeiras a buracos distintos**.

## 2. Interpretação da entrada e da saída

**Entrada** (vários casos, até o fim do arquivo):

- Primeira linha do caso: `n m s v` (quatro inteiros positivos < 100).
- `n` linhas seguintes: coordenadas `x y` das toupeiras.
- `m` linhas seguintes: coordenadas `x y` dos buracos.

**Saída:** uma linha por caso com o número de toupeiras vulneráveis.

A resposta sai do fluxo assim: `vulneráveis = n − (toupeiras salvas)`, onde
"toupeiras salvas" é o fluxo máximo da rede.

## 3. Modelagem da rede de fluxo

| Componente | No problema |
|---|---|
| **Origem** | ponto de partida; injeta 1 unidade por toupeira |
| **Camada 1 (n vértices)** | as toupeiras |
| **Camada 2 (m vértices)** | os buracos |
| **Sorvedouro** | "toupeira salva"; cada buraco escoa 1 unidade |

**Arestas e capacidades:**

- `origem → toupeira_i`, capacidade `1` → cada toupeira é salva no máximo 1 vez.
- `toupeira_i → buraco_j`, capacidade `1`, **se** `dist²(i,j) ≤ (s·v)²` →
  compatibilidade (a toupeira alcança o buraco a tempo).
- `buraco_j → sorvedouro`, capacidade `1` → cada buraco salva no máximo 1 toupeira.

Uma unidade de fluxo `origem → toupeira → buraco → sorvedouro` significa
**uma toupeira salva**. O fluxo máximo é o emparelhamento máximo.

## 4. Justificativa da escolha entre Ford-Fulkerson e Edmonds-Karp

Escolhemos **Edmonds-Karp** (Ford-Fulkerson com BFS). Motivos:

- As capacidades são unitárias e o grafo é pequeno (`n, m < 100`), então qualquer
  um dos dois resolve com folga.
- O BFS torna o número de aumentos previsível e dá um comportamento estável,
  como recomenda o enunciado em caso de dúvida.

## 5. Instância pequena (a do enunciado)

```
2 2 5 10
1.0 1.0      (toupeira G1)
2.0 2.0      (toupeira G2)
100.0 100.0  (buraco H1)
20.0 20.0    (buraco H2)
```

Alcance máximo: `s · v = 5 · 10 = 50` metros. Comparamos com `50² = 2500`.

Distâncias ao quadrado:

| par | cálculo | dist² | alcança? (≤ 2500) |
|---|---|---|---|
| G1–H1 | (1−100)² + (1−100)² = 9801 + 9801 | 19602 | não |
| G1–H2 | (1−20)² + (1−20)² = 361 + 361 | 722 | **sim** |
| G2–H1 | (2−100)² + (2−100)² = 9604 + 9604 | 19208 | não |
| G2–H2 | (2−20)² + (2−20)² = 324 + 324 | 648 | **sim** |

Ou seja: G1 e G2 só alcançam o buraco H2. O buraco H1 não serve para ninguém.

**Rede resultante:**

```
        cap1        compat(cap1)        cap1
 source ----> G1 -------------\
        ----> G2 ----------\   \
                            v   v
                            H2 ----> sink        (H1 fica isolado, sem aresta útil)
```

## 6. Execução manual passo a passo (Edmonds-Karp)

Estado inicial: todas as capacidades como descritas, fluxo = 0.

**Iteração 1 — BFS procura caminho de `source` a `sink`:**

- `source → G1` (cap 1, livre) → `G1 → H2` (cap 1, livre) → `H2 → sink` (cap 1, livre).
- Caminho aumentante encontrado: `source → G1 → H2 → sink`.
- Gargalo = menor capacidade do caminho = `1`.
- Atualiza residual: zera `source→G1`, `G1→H2`, `H2→sink`; cria capacidade `1`
  nas reversas correspondentes.
- **fluxo = 1**.

**Iteração 2 — BFS procura novo caminho:**

- `source → G1` já está saturada (cap 0).
- `source → G2` (cap 1, livre) → `G2 → H2` (cap 1, livre) → mas `H2 → sink` está
  **saturada** (cap 0).
- A única saída de H2 pela reversa seria voltar para uma toupeira, mas isso não
  leva ao sorvedouro por nenhum buraco livre (H1 não tem aresta para o sink útil,
  pois nenhuma toupeira o alcança).
- **Não há caminho aumentante.** O algoritmo para.

**Fluxo máximo final = 1.**

## 7. Verificação da resposta final

- Toupeiras salvas = fluxo máximo = `1` (apenas uma das duas consegue ocupar H2).
- Vulneráveis = `n − fluxo = 2 − 1 = 1`.

**Saída esperada: `1`** — confere com o exemplo oficial do enunciado. ✔

A interpretação faz sentido: as duas toupeiras só alcançam o mesmo buraco (H2), e
como o buraco abriga apenas uma, exatamente uma toupeira fica vulnerável.
