import sys
from collections import deque


class MaxFlow:
    """
    Rede de fluxo com lista de adjacencia e arestas residuais.
    Cada aresta guarda a referencia (indice) da sua aresta reversa,
    permitindo desfazer escolhas anteriores durante a busca.
    Algoritmo: Edmonds-Karp (Ford-Fulkerson com BFS).
    """

    def __init__(self, n):
        self.n = n
        self.graph = [[] for _ in range(n)]  # graph[u] = lista de indices de arestas
        self.edges = []  # cada aresta: [destino, capacidade_residual]

    def add_edge(self, u, v, cap):
        # aresta direta u->v com capacidade cap
        self.graph[u].append(len(self.edges))
        self.edges.append([v, cap])
        # aresta reversa v->u com capacidade 0
        self.graph[v].append(len(self.edges))
        self.edges.append([u, 0])

    def bfs(self, source, sink, parent_edge):
        """Procura um caminho aumentante da origem ao sorvedouro no grafo residual."""
        visited = [False] * self.n
        visited[source] = True
        queue = deque([source])
        while queue:
            u = queue.popleft()
            for eid in self.graph[u]:
                v, cap = self.edges[eid]
                if not visited[v] and cap > 0:
                    visited[v] = True
                    parent_edge[v] = eid
                    if v == sink:
                        return True
                    queue.append(v)
        return False

    def max_flow(self, source, sink):
        flow = 0
        parent_edge = [-1] * self.n
        while self.bfs(source, sink, parent_edge):
            # gargalo: como todas as capacidades aqui sao unitarias, o gargalo e sempre 1,
            # mas calculamos de forma geral para manter a logica correta.
            bottleneck = float("inf")
            v = sink
            while v != source:
                eid = parent_edge[v]
                bottleneck = min(bottleneck, self.edges[eid][1])
                v = self.edges[eid ^ 1][0]  # origem da aresta = destino da reversa
            # atualiza capacidades residuais ao longo do caminho
            v = sink
            while v != source:
                eid = parent_edge[v]
                self.edges[eid][1] -= bottleneck      # consome capacidade na aresta direta
                self.edges[eid ^ 1][1] += bottleneck  # devolve na aresta reversa
                v = self.edges[eid ^ 1][0]
            flow += bottleneck
        return flow


def solve():
    data = sys.stdin.read().split()
    idx = 0
    out = []
    while idx < len(data):
        # le cabecalho do caso: n m s v
        if idx + 4 > len(data):
            break
        n = int(data[idx]); m = int(data[idx + 1])
        s = float(data[idx + 2]); v = float(data[idx + 3])
        idx += 4

        gophers = []
        for _ in range(n):
            x = float(data[idx]); y = float(data[idx + 1])
            gophers.append((x, y))
            idx += 2

        holes = []
        for _ in range(m):
            x = float(data[idx]); y = float(data[idx + 1])
            holes.append((x, y))
            idx += 2

        # alcance maximo: distancia que a toupeira percorre em s segundos a velocidade v
        reach = s * v
        reach_sq = reach * reach  # comparamos distancias ao quadrado (evita sqrt e erros de ponto flutuante)

        # ---- Construcao da rede ----
        # Numeracao dos vertices:
        #   source = 0
        #   toupeiras = 1 .. n
        #   buracos   = n+1 .. n+m
        #   sink = n+m+1
        source = 0
        sink = n + m + 1
        mf = MaxFlow(n + m + 2)

        # source -> cada toupeira (capacidade 1): cada toupeira e salva por no maximo um buraco
        for i in range(n):
            mf.add_edge(source, 1 + i, 1)

        # cada buraco -> sink (capacidade 1): cada buraco salva no maximo uma toupeira
        for j in range(m):
            mf.add_edge(1 + n + j, sink, 1)

        # toupeira -> buraco (capacidade 1) se a toupeira alcanca o buraco a tempo
        for i, (gx, gy) in enumerate(gophers):
            for j, (hx, hy) in enumerate(holes):
                dist_sq = (gx - hx) ** 2 + (gy - hy) ** 2
                if dist_sq <= reach_sq:
                    mf.add_edge(1 + i, 1 + n + j, 1)

        saved = mf.max_flow(source, sink)  # numero maximo de toupeiras salvas (emparelhamento maximo)
        vulnerable = n - saved             # as demais ficam vulneraveis
        out.append(str(vulnerable))

    sys.stdout.write("\n".join(out) + ("\n" if out else ""))


if __name__ == "__main__":
    solve()
